import TodoAp from "./components/TodoApp";

function App() {
  return (
    <>
      <TodoAp></TodoAp>
    </>
  );
}

export default App;
