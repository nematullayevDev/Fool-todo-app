import { useSelector } from "react-redux";
import Form from "../Form";
import TodoItem from "../TodoItem";
import TodoTitle from "../TodoTitile";
import { useEffect, useState } from "react";

function TodoAp() {
  const todos = useSelector((state) => state.todos.todos);
  const [activeTodos, setActiveTodos] = useState([]);
  const [inactiveTodos, setInactiveTodos] = useState([]);

//   PASDAGINI KOMENTARYADAN CHIQASEZ HATOLIK BERAYABIID

    // useEffect(() => {
    //   let active = todos.filter((el) => {
    //     return el.status == true;
    //   });

    //   setActiveTodos(active);

    //   let inactive = todos.filter((el) => {
    //     return el.status == false;
    //   });

    //   setInactiveTodos(inactive);
    // }, [todos]);

  return (
    <>
      <div className="w-[432px] mx-auto mt-40">
        <Form />
        <TodoTitle title="Tasks to do" status={false} count={4} />

        {todos.length > 0 &&
          activeTodos.map((todo, index) => {
            return <TodoItem key={index} title={todo.name} status={true} />;
          })}

        <TodoTitle title="Done" status={false} count={1} />

        {todos.length > 0 &&
          inactiveTodos.map((todo, index) => {
            return <TodoItem key={index} title={todo.name} status={false} />;
          })}
        {/* <TodoItem title="To study React fundamentals" status={false} /> */}
        {/* <TodoItem title="To study React fundamentals" status={false} /> */}
      </div>
    </>
  );
}

export default TodoAp;
